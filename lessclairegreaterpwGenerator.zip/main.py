import random
#lists for possible types of characters
alpha = ["A", "B", "C", "D", "E","F","G","H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
alphaL = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
num = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
special = ["!", "@", "#", "$", "%", "^", "&", "*"]

pw = ["", "", "", "", "", "", "", "", "", ""]

#pw[0] = random.choice(alpha)
#pw[1] = random.choice(alpha)
#pw[2] = random.choice(alphaL)
#pw[3] = random.choice(alpha)
#pw[4] = random.choice(alphaL)
#pw[5] = random.choice(alphaL)
#pw[6] = random.choice(alpha)
#pw[7] = random.choice(special)
#pw[8] = random.choice(num)
#pw[9] = random.choice(alphaL)

#joins list index --> string
x = ""
pwS = x.join(pw)

#new password generator (random pattern)
pw2 = ["", "", "", "", "", "", "", "", "", ""]
for i in range (0, 10):
  rx = random.randint(1, 4)
  if (rx == 1):
    index = alpha
  if (rx == 2):
    index = alphaL
  if (rx == 3):
    index = num
  if (rx == 4):
    index = special
  pw[i] = random.choice(index)
  print(pw[i], end="")
